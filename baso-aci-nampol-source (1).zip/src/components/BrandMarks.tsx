import { cn } from "@/lib/utils";

/**
 * Tanda merek Shopee & TikTok.
 * Digambar ulang sebagai SVG inline supaya tidak perlu menambah dependensi
 * ikon merek dan tetap ikut warna tema.
 */

export function ShopeeMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.9}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className={cn("size-5", className)}
    >
      <path d="M6.2 2.8 3.4 6.6v12.4a2.2 2.2 0 0 0 2.2 2.2h12.8a2.2 2.2 0 0 0 2.2-2.2V6.6l-2.8-3.8z" />
      <path d="M3.4 6.6h17.2" />
      <path d="M16.4 10.4c0 2.4-1.9 3.9-4.4 3.9s-4.4-1.5-4.4-3.9" />
    </svg>
  );
}

export function TikTokMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="currentColor"
      aria-hidden
      className={cn("size-5", className)}
    >
      <path d="M12.53.02C13.84 0 15.14.01 16.44 0c.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.62 2.79-1.53.2-.32.4-.66.4-1.08.11-2.18.06-4.36.07-6.54.02-4.28-.01-8.56.02-12.83z" />
    </svg>
  );
}
