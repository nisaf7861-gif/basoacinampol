import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, Flame, MapPin } from "lucide-react";

import packshot from "@/assets/packshot.png";
import tekstur from "@/assets/tekstur.jpg";
import mangkuk from "@/assets/mangkuk.jpg";
import { Reveal } from "@/components/Reveal";
import { ShopeeMark, TikTokMark } from "@/components/BrandMarks";
import { cn } from "@/lib/utils";
import { MENU } from "@/lib/menu";
import { Rekomendasi } from "@/components/Rekomendasi";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Baso Aci Nampol — Snack Aci Garing Pedas Nampol" },
      {
        name: "description",
        content:
          "Baso aci digoreng garing, ditabur cabai rawit asli. Pilih level pedas 1–5, lihat menu & harga mulai Rp 12.000, pesan cepat lewat WhatsApp.",
      },
      { property: "og:title", content: "Baso Aci Nampol" },
      {
        property: "og:description",
        content:
          "Garing ditengkorak, pedasnya nampol. Menu original sampai level 5, paket hemat, dan borongan 1 kg.",
      },
      { property: "og:type", content: "website" },
      { property: "og:site_name", content: "Baso Aci Nampol" },
      { property: "og:locale", content: "id_ID" },
      { name: "twitter:card", content: "summary_large_image" },
      { name: "twitter:title", content: "Baso Aci Nampol" },
      {
        name: "twitter:description",
        content:
          "Garing ditengkorak, pedasnya nampol. Menu original sampai level 5, paket hemat, dan borongan 1 kg.",
      },
      { name: "theme-color", content: "#c8341f" },
    ],
  }),
  component: Index,
});

const WA_NUMBER = "6285725417459";
const waLink = (text: string) =>
  `https://wa.me/${WA_NUMBER}?text=${encodeURIComponent(text)}`;

const SHOPEE_URL = "https://id.shp.ee/2EKmRYW3";
const TIKTOK_URL = "https://www.tiktok.com/@bocinampol_";
const TIKTOK_HANDLE = "@bocinampol_";

const ALAMAT =
  "Jl. Kepa Duri No. A63, Kel. Duri Kepa, Kec. Kebon Jeruk, Jakarta Barat";
const MAPS_URL = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(
  ALAMAT,
)}`;

const LEVELS = [
  { n: 1, label: "Gemas" },
  { n: 2, label: "Nyangsang" },
  { n: 3, label: "Nampol" },
  { n: 4, label: "Bakar" },
  { n: 5, label: "Matian" },
];

const ALASANS = [
  {
    no: "01",
    text: "100% aci pilihan, digoreng garing jadi tahan renyah lebih lama.",
  },
  {
    no: "02",
    text: "Cabai rawit asli digiling sendiri — bukan bubuk penyedap.",
  },
  {
    no: "03",
    text: "Tanpa pengawet, digoreng fresh tiap pagi sebelum dikirim.",
  },
  {
    no: "04",
    text: "Dikemas sealed rapat, sampai di rumah masih kres.",
  },
];

function Wordmark() {
  return (
    <span className="font-display text-[15px] leading-none tracking-tight sm:text-lg">
      BASO ACI<span className="text-primary"> NAMPOL</span>
    </span>
  );
}

function SectionTitle({
  children,
  aside,
}: {
  children: string;
  aside?: string;
}) {
  return (
    <div className="flex items-end justify-between gap-3">
      <h2 className="text-3xl tracking-tight text-balance">{children}</h2>
      {aside ? (
        <span className="shrink-0 pb-1 font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
          {aside}
        </span>
      ) : null}
    </div>
  );
}

function LevelPips({ level }: { level: number }) {
  if (level <= 0) {
    return (
      <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
        no pedas
      </span>
    );
  }
  return (
    <span className="flex items-center gap-0.5" aria-label={`Level ${level}`}>
      {Array.from({ length: 5 }, (_, i) => (
        <span
          key={i}
          aria-hidden
          className={cn(
            "size-1.5 rounded-full",
            i < level ? "bg-chili" : "bg-foreground/15",
          )}
        />
      ))}
    </span>
  );
}

function Index() {
  return (
    <div className="min-h-screen bg-background font-body text-foreground">
      {/* Nav */}
      <nav className="sticky top-0 z-30 border-b border-line/40 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-3xl items-center justify-between gap-2 px-4">
          <Wordmark />
          <div className="flex items-center gap-1.5">
            <a
              href={SHOPEE_URL}
              target="_blank"
              rel="noreferrer"
              aria-label="Toko Shopee Baso Aci Nampol"
              className="grid size-9 place-items-center rounded-full bg-shopee/12 text-shopee ring-1 ring-shopee/25 transition-transform active:translate-y-px"
            >
              <ShopeeMark />
            </a>
            <a
              href={TIKTOK_URL}
              target="_blank"
              rel="noreferrer"
              aria-label="TikTok Baso Aci Nampol @bocinampol_"
              className="grid size-9 place-items-center rounded-full bg-tiktok/10 text-tiktok ring-1 ring-tiktok/25 transition-transform active:translate-y-px"
            >
              <TikTokMark />
            </a>
            <a
              href={waLink("Halo Baso Aci Nampol, mau pesan dong")}
              target="_blank"
              rel="noreferrer"
              className="rounded-full bg-primary px-3.5 py-2 text-xs font-bold text-primary-foreground transition-transform active:translate-y-px"
            >
              Pesan via WA
            </a>
          </div>
        </div>
      </nav>

      <main className="mx-auto max-w-3xl px-4">
        {/* Hero */}
        <section className="relative pt-8 pb-2">
          <div className="relative grid gap-6 sm:grid-cols-[1.05fr_0.95fr] sm:items-center">
            <div className="anim-pop order-2 sm:order-1">
              <span className="anim-flick inline-block rounded-full bg-primary px-3 py-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.18em] text-primary-foreground">
                Pedas Level 5
              </span>
              <p className="mt-4 font-mono text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
                Snack garing · Pedas nampol
              </p>
              <h1 className="mt-2 text-[2.9rem] leading-[1.05] tracking-tight text-balance sm:text-[4.5rem] sm:leading-[0.98]">
                GARING
                <br />
                DITENGKORAK
                <br />
                <span className="text-primary">NAMPOL</span>
              </h1>
              <p className="mt-4 max-w-[34ch] text-sm leading-relaxed text-pretty text-muted-foreground">
                Baso aci digoreng kering, ditabur cabai rawit giling. Gigitan
                pertama langsung bunyi, pedasnya nyusul dan bikin nagih.
              </p>
              <div className="mt-6 flex flex-wrap items-center gap-3">
                <a
                  href="#menu"
                  className="rounded-full bg-char px-4 py-2.5 text-xs font-bold text-background transition-transform active:translate-y-px"
                >
                  Lihat Menu & Harga
                </a>
                <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-muted-foreground">
                  Mulai Rp 12.000
                </span>
              </div>
            </div>

            {/* Packshot bleeding keluar tepi */}
            <div className="anim-pop relative order-1 sm:order-2 [animation-delay:120ms]">
              <div className="absolute inset-0 -z-10 rotate-6 rounded-3xl bg-gradient-to-br from-turmeric via-turmeric to-secondary-foreground/20 sm:scale-110" />
              <div className="absolute -top-4 -left-4 -z-10 size-24 rounded-full bg-primary/15 blur-2xl" />
              <img
                src={packshot}
                alt="Kemasan Baso Aci Nampol warna merah cabai"
                width={1024}
                height={1280}
                className="mx-auto w-[74%] -rotate-3 rounded-xl object-cover drop-shadow-[0_24px_36px_oklch(0.1756_0.0151_81.44/0.28)] sm:w-[88%]"
              />
              <span className="absolute bottom-6 left-0 -rotate-6 bg-char px-3 py-1 font-display text-lg leading-none text-turmeric sm:left-4">
                Rp 12rb-an
              </span>
            </div>
          </div>
        </section>

        {/* Band tekstur */}
        <Reveal className="mt-10">
          <figure className="relative overflow-hidden rounded-2xl ring-1 ring-char/10">
            <img
              src={tekstur}
              alt="Baso aci garing ditabur cabai rawit"
              width={1200}
              height={912}
              loading="lazy"
              className="h-52 w-full object-cover sm:h-64"
            />
            <figcaption className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-char/85 to-transparent px-4 pt-10 pb-3 text-xs font-semibold text-background">
              Ditabur cabai rawit giling, bukan bubuk penyedap.
            </figcaption>
          </figure>
        </Reveal>

        {/* Level pedas */}
        <section className="mt-12">
          <Reveal>
            <SectionTitle aside="1–5">Level Pedas</SectionTitle>
          </Reveal>
          <div className="mt-4 grid grid-cols-5 gap-1.5 sm:gap-2">
            {LEVELS.map((l, i) => (
              <Reveal key={l.n} delay={60 + i * 60}>
                <div
                  className={cn(
                    "grid h-16 place-items-center rounded-xl sm:h-20",
                    l.n === 3
                      ? "bg-primary/10 ring-2 ring-primary"
                      : "bg-muted",
                  )}
                >
                  <span
                    className={cn(
                      "font-display text-2xl leading-none sm:text-4xl",
                      l.n >= 4 ? "text-chili-deep" : "text-chili",
                    )}
                  >
                    {l.n}
                  </span>
                  <span className="mt-1 font-mono text-[9px] uppercase tracking-[0.1em] text-muted-foreground">
                    {l.label}
                  </span>
                </div>
              </Reveal>
            ))}
          </div>
          <Reveal delay={120}>
            <p className="mt-3 text-xs text-muted-foreground">
              Level di atas 4 disarankan buat yang jago cabai. Mau request level
              khusus atau campur? Tinggal bilang di chat.
            </p>
          </Reveal>
        </section>

        <Rekomendasi waLink={waLink} />

        {/* Menu & harga */}
        <section id="menu" className="mt-12 scroll-mt-20">
          <Reveal>
            <SectionTitle aside="Rupiah">Menu & Harga</SectionTitle>
          </Reveal>
          <Reveal delay={80}>
            <div className="mt-4 rounded-2xl bg-char px-4 py-5 text-background ring-1 ring-char/20 sm:px-6">
              <ul className="space-y-4">
                {MENU.map((item) => (
                  <li key={item.name}>
                    <div className="flex items-baseline gap-2">
                      <span className="flex items-baseline gap-2 whitespace-nowrap">
                        <span className="text-[15px] font-bold">{item.name}</span>
                        {item.tag ? (
                          <span className="rounded-full bg-turmeric px-2 py-0.5 font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-char">
                            {item.tag}
                          </span>
                        ) : null}
                      </span>
                      <span className="leader leader-dark" aria-hidden />
                      <span className="font-display text-lg leading-none whitespace-nowrap">
                        {item.price}
                      </span>
                    </div>
                    <div className="mt-1.5 flex items-center justify-between gap-3">
                      <p className="max-w-[46ch] text-xs leading-relaxed text-pretty text-background/60">
                        {item.note}
                      </p>
                      {item.level !== null ? (
                        <span className="shrink-0">
                          <LevelPips level={item.level} />
                        </span>
                      ) : null}
                    </div>
                  </li>
                ))}
              </ul>
              <p className="mt-5 border-t border-background/15 pt-4 font-mono text-[10px] uppercase tracking-[0.14em] text-background/50">
                Harga belum termasuk ongkir · Min. 2 bungkus
              </p>
            </div>
          </Reveal>
        </section>

        {/* Signature kuah */}
        <section className="mt-12">
          <Reveal>
            <SectionTitle aside="Baru">Versi Kuah</SectionTitle>
          </Reveal>
          <Reveal delay={80}>
            <div className="mt-4 grid gap-4 overflow-hidden rounded-2xl bg-card p-4 ring-1 ring-line/50 sm:grid-cols-[1fr_1.1fr] sm:items-center">
              <img
                src={mangkuk}
                alt="Semangkuk baso aci kuah cabai"
                width={1200}
                height={912}
                loading="lazy"
                className="h-48 w-full rounded-xl object-cover sm:h-56"
              />
              <div>
                <h3 className="text-2xl leading-none tracking-tight">
                  Baso Aci Mangkuk
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-pretty text-muted-foreground">
                  Aci kenyal + kuah cabai nampol, pakai daging cincang, kacang
                  panjang, dan bawang goreng. Dimakan siang hari, habis duluan.
                </p>
                <div className="mt-4 flex flex-wrap items-center gap-3">
                  <span className="font-display text-2xl leading-none text-primary">
                    Rp 15.000
                  </span>
                  <a
                    href={waLink("Mau Baso Aci Mangkuk 1 porsi dong")}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-1 rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground transition-transform active:translate-y-px"
                  >
                    Pesan menu ini <ArrowUpRight className="size-3.5" />
                  </a>
                </div>
              </div>
            </div>
          </Reveal>
        </section>

        {/* Kenapa nampol */}
        <section className="mt-12">
          <Reveal>
            <SectionTitle aside="4 alasan">Kenapa Nampol?</SectionTitle>
          </Reveal>
          <ul className="mt-4 grid gap-3">
            {ALASANS.map((a, i) => (
              <Reveal key={a.no} as="li" delay={i * 70}>
                <div className="flex items-center gap-3 rounded-xl bg-primary/8 px-4 py-3.5 ring-1 ring-primary/10">
                  <span className="w-8 shrink-0 text-center font-display text-2xl text-primary">
                    {a.no}
                  </span>
                  <p className="text-sm leading-relaxed text-pretty text-foreground/80">
                    {a.text}
                  </p>
                </div>
              </Reveal>
            ))}
          </ul>
        </section>

        {/* Belanja online */}
        <section id="online" className="mt-12 scroll-mt-20">
          <Reveal>
            <SectionTitle aside="Shopee & TikTok">
              Belanja Online
            </SectionTitle>
          </Reveal>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <Reveal delay={60}>
              <a
                href={SHOPEE_URL}
                target="_blank"
                rel="noreferrer"
                className="flex h-full flex-col justify-between gap-4 rounded-2xl bg-shopee p-4 text-background ring-1 ring-char/10 transition-transform active:translate-y-px sm:p-5"
              >
                <div className="flex items-start justify-between gap-3">
                  <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-background/70">
                    Official Store
                  </span>
                  <ShopeeMark className="size-7 text-background" />
                </div>
                <div>
                  <p className="font-display text-3xl leading-[0.95] tracking-tight">
                    TOKO
                    <br />
                    SHOPEE
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-background/80">
                    Checkout lewat aplikasi Shopee, pesanan terpantau dari
                    bayar sampai di rumah.
                  </p>
                  <span className="mt-4 inline-flex items-center gap-1 rounded-full bg-background/20 px-3 py-1.5 text-xs font-bold">
                    Buka toko <ArrowUpRight className="size-3.5" />
                  </span>
                </div>
              </a>
            </Reveal>

            <Reveal delay={130}>
              <a
                href={TIKTOK_URL}
                target="_blank"
                rel="noreferrer"
                className="relative flex h-full flex-col justify-between gap-4 overflow-hidden rounded-2xl bg-tiktok p-4 text-background ring-1 ring-char/10 transition-transform active:translate-y-px sm:p-5"
              >
                <span
                  aria-hidden
                  className="absolute -top-10 -right-8 size-32 rounded-full bg-tiktok-pink/25 blur-2xl"
                />
                <span
                  aria-hidden
                  className="absolute -bottom-12 -left-6 size-28 rounded-full bg-tiktok-cyan/20 blur-2xl"
                />
                <div className="relative flex items-start justify-between gap-3">
                  <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-background/70">
                    {TIKTOK_HANDLE}
                  </span>
                  <span className="relative">
                    <TikTokMark className="relative z-10 size-7 text-background" />
                    <TikTokMark className="absolute inset-0 translate-x-[3px] -translate-y-[2px] size-7 text-tiktok-pink" />
                    <TikTokMark className="absolute inset-0 -translate-x-[3px] translate-y-[2px] size-7 text-tiktok-cyan" />
                  </span>
                </div>
                <div className="relative">
                  <p className="font-display text-3xl leading-[0.95] tracking-tight">
                    FOLLOW
                    <br />
                    TIKTOK
                  </p>
                  <p className="mt-2 text-xs leading-relaxed text-background/80">
                    Video baso aci, review pedas, dan kabar menu terbaru tiap
                    minggu.
                  </p>
                  <span className="mt-4 inline-flex items-center gap-1 rounded-full bg-background/20 px-3 py-1.5 text-xs font-bold">
                    Follow {TIKTOK_HANDLE} <ArrowUpRight className="size-3.5" />
                  </span>
                </div>
              </a>
            </Reveal>
          </div>
        </section>

        {/* CTA */}
        <section className="mt-12 pb-16">
          <Reveal>
            <a
              href={waLink("Halo, mau pesan Baso Aci Nampol")}
              target="_blank"
              rel="noreferrer"
              className="block rounded-2xl bg-primary px-5 py-6 text-primary-foreground ring-1 ring-char/10 transition-transform active:translate-y-px"
            >
              <div className="flex items-end justify-between gap-3">
                <div>
                  <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-primary-foreground/60">
                    Ready? Gas
                  </p>
                  <p className="mt-1 font-display text-4xl leading-[0.95] tracking-tight">
                    PESAN
                    <br />
                    LEWAT WA
                  </p>
                </div>
                <Flame className="size-10 shrink-0 text-turmeric" />
              </div>
              <p className="mt-4 text-xs text-primary-foreground/70">
                Chat sekarang, tulis level pedas & jumlahnya. Kita kemas renyah,
                fast reply.
              </p>
            </a>
          </Reveal>

          <Reveal delay={80}>
            <div className="mt-4 flex items-start gap-3 rounded-2xl bg-card px-4 py-4 ring-1 ring-char/10">
              <MapPin className="mt-0.5 size-5 shrink-0 text-primary" />
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
                  Alamat
                </p>
                <p className="mt-1 text-sm leading-relaxed font-medium text-pretty">
                  {ALAMAT}
                </p>
                <a
                  href={MAPS_URL}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-2 inline-flex items-center gap-1 font-mono text-[10px] uppercase tracking-[0.14em] text-primary"
                >
                  Buka di Google Maps <ArrowUpRight className="size-3.5" />
                </a>
              </div>
            </div>
          </Reveal>

          <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
            <a
              href={SHOPEE_URL}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full bg-card px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-shopee ring-1 ring-shopee/25"
            >
              <ShopeeMark className="size-3.5" /> Shopee
            </a>
            <a
              href={TIKTOK_URL}
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center gap-1.5 rounded-full bg-card px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] text-tiktok ring-1 ring-tiktok/20"
            >
              <TikTokMark className="size-3.5" /> {TIKTOK_HANDLE}
            </a>
          </div>

          <p className="mt-6 text-center font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
            Baso Aci Nampol · UMKM Lokal · Duri Kepa, Kebon Jeruk
          </p>
        </section>
      </main>
    </div>
  );
}
