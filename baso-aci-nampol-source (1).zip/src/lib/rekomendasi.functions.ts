import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { MENU } from "./menu";

const Input = z.object({
  level: z.number().int().min(0).max(5),
  porsi: z.enum(["sendiri", "berdua", "rame", "stok"]),
  catatan: z.string().max(300).optional().default(""),
});

export type Rekom = { items: { name: string; qty: number; reason: string }[]; summary: string };

export const rekomendasiMenu = createServerFn({ method: "POST" })
  .inputValidator((d) => Input.parse(d))
  .handler(async ({ data }): Promise<{ ok: true; result: Rekom } | { ok: false; error: string }> => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) return { ok: false, error: "Fitur rekomendasi belum siap." };
    const porsiText = {
      sendiri: "untuk 1 orang",
      berdua: "untuk 2 orang",
      rame: "untuk rame-rame 4-6 orang",
      stok: "untuk stok / dijual lagi",
    }[data.porsi];
    const menuText = MENU.map(
      (m) => `- ${m.name} | ${m.price} | level: ${m.level ?? "campur/pilih"} | ${m.note}`,
    ).join("\n");
    const prompt = `Kamu kasir ramah "Baso Aci Nampol". Rekomendasikan pesanan HANYA dari menu ini:\n${menuText}\n\nPelanggan: level pedas ${data.level} (0=tidak pedas, 5=paling pedas), porsi ${porsiText}. Catatan: ${data.catatan || "-"}.\n\nBalas JSON saja: {"items":[{"name":"<nama menu persis>","qty":<angka>,"reason":"<alasan singkat santai>"}],"summary":"<1-2 kalimat santai bahasa Indonesia, sebut perkiraan total harga>"}. Maksimal 3 item.`;
    try {
      const res = await fetch("https://ai.gateway.lovable.dev/v1/responses", {
        method: "POST",
        headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "openai/gpt-6-astra",
          input: prompt,
          text: { format: { type: "json_object" } },
        }),
      });
      if (!res.ok) {
        console.error("AI error", res.status, await res.text());
        if (res.status === 429) return { ok: false, error: "Lagi rame, coba lagi sebentar ya." };
        if (res.status === 402) return { ok: false, error: "Kuota AI habis, hubungi penjual via WA." };
        return { ok: false, error: "Rekomendasi gagal dibuat, coba lagi nanti." };
      }
      const j = await res.json();
      const text: string =
        j.output_text ??
        (j.output ?? [])
          .flatMap((o: { content?: { type: string; text?: string }[] }) => o.content ?? [])
          .filter((c: { type: string }) => c.type === "output_text")
          .map((c: { text?: string }) => c.text ?? "")
          .join("");
      const parsed = JSON.parse(text.slice(text.indexOf("{"), text.lastIndexOf("}") + 1)) as Rekom;
      const names = new Set(MENU.map((m) => m.name));
      parsed.items = (parsed.items ?? []).filter((i) => names.has(i.name)).slice(0, 3);
      if (!parsed.items.length) return { ok: false, error: "Belum nemu yang pas, coba ubah pilihanmu." };
      return { ok: true, result: parsed };
    } catch (e) {
      console.error(e);
      return { ok: false, error: "Rekomendasi gagal dibuat, coba lagi nanti." };
    }
  });
