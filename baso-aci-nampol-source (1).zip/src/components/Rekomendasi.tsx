import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Flame, Sparkles } from "lucide-react";
import { rekomendasiMenu, type Rekom } from "@/lib/rekomendasi.functions";
import { MENU } from "@/lib/menu";
import { cn } from "@/lib/utils";

const PORSI = [
  { v: "sendiri", l: "Sendiri" },
  { v: "berdua", l: "Berdua" },
  { v: "rame", l: "Rame-rame" },
  { v: "stok", l: "Stok / jualan" },
] as const;

export function Rekomendasi({ waLink }: { waLink: (t: string) => string }) {
  const run = useServerFn(rekomendasiMenu);
  const [level, setLevel] = useState(3);
  const [porsi, setPorsi] = useState<(typeof PORSI)[number]["v"]>("sendiri");
  const [catatan, setCatatan] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [res, setRes] = useState<Rekom | null>(null);

  const submit = async () => {
    setLoading(true);
    setErr("");
    setRes(null);
    try {
      const r = await run({ data: { level, porsi, catatan } });
      if (r.ok) setRes(r.result);
      else setErr(r.error);
    } catch {
      setErr("Rekomendasi gagal dibuat, coba lagi nanti.");
    } finally {
      setLoading(false);
    }
  };

  const pesan = res
    ? `Halo Baso Aci Nampol, saya mau pesan:\n${res.items.map((i) => `- ${i.qty}x ${i.name}`).join("\n")}\nLevel pedas: ${level}${catatan ? `\nCatatan: ${catatan}` : ""}`
    : "";

  return (
    <section id="rekomendasi" className="mt-12 scroll-mt-20">
      <div className="rounded-2xl border-2 border-char bg-secondary/40 p-4 sm:p-6">
        <p className="font-mono text-xs uppercase tracking-widest text-primary">Bingung pilih?</p>
        <h2 className="mt-1 font-display text-3xl uppercase leading-none text-char sm:text-4xl">
          Racik pesananmu
        </h2>

        <label className="mt-5 block font-mono text-xs uppercase text-char/70">
          Level pedas: <span className="text-primary">{level === 0 ? "Nggak pedas" : `Level ${level}`}</span>
        </label>
        <div className="mt-2 flex gap-1.5">
          {[0, 1, 2, 3, 4, 5].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setLevel(n)}
              className={cn(
                "flex h-11 flex-1 items-center justify-center rounded-lg border-2 border-char font-display text-lg",
                n === level ? "bg-primary text-primary-foreground" : "bg-background text-char",
              )}
            >
              {n === 0 ? "0" : <span className="flex items-center">{n}<Flame className="h-3.5 w-3.5" /></span>}
            </button>
          ))}
        </div>

        <label className="mt-5 block font-mono text-xs uppercase text-char/70">Porsi</label>
        <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4">
          {PORSI.map((p) => (
            <button
              key={p.v}
              type="button"
              onClick={() => setPorsi(p.v)}
              className={cn(
                "h-11 rounded-lg border-2 border-char text-sm font-semibold",
                p.v === porsi ? "bg-char text-background" : "bg-background text-char",
              )}
            >
              {p.l}
            </button>
          ))}
        </div>

        <label className="mt-5 block font-mono text-xs uppercase text-char/70">Request lain (opsional)</label>
        <textarea
          value={catatan}
          onChange={(e) => setCatatan(e.target.value.slice(0, 300))}
          rows={2}
          placeholder="Contoh: budget 30 ribu, buat nonton bola"
          className="mt-2 w-full rounded-lg border-2 border-char bg-background p-3 text-sm text-char outline-none focus:border-primary"
        />

        <button
          type="button"
          onClick={submit}
          disabled={loading}
          className="mt-4 flex h-12 w-full items-center justify-center gap-2 rounded-lg bg-primary font-display text-lg uppercase text-primary-foreground disabled:opacity-60"
        >
          <Sparkles className="h-5 w-5" />
          {loading ? "Lagi diracik..." : "Kasih rekomendasi"}
        </button>

        {err && <p className="mt-3 text-sm font-semibold text-primary">{err}</p>}

        {res && (
          <div className="mt-5 rounded-xl bg-char p-4 text-background">
            <ul className="space-y-3">
              {res.items.map((i) => (
                <li key={i.name}>
                  <div className="flex items-baseline justify-between gap-2">
                    <span className="font-display text-lg uppercase">
                      {i.qty}x {i.name}
                    </span>
                    <span className="font-mono text-sm text-secondary">
                      {MENU.find((m) => m.name === i.name)?.price}
                    </span>
                  </div>
                  <p className="text-sm text-background/75">{i.reason}</p>
                </li>
              ))}
            </ul>
            <p className="mt-3 border-t border-background/20 pt-3 text-sm">{res.summary}</p>
            <a
              href={waLink(pesan)}
              target="_blank"
              rel="noreferrer"
              className="mt-4 flex h-11 items-center justify-center rounded-lg bg-secondary font-display uppercase text-char"
            >
              Pesan ini via WA
            </a>
          </div>
        )}
      </div>
    </section>
  );
}
