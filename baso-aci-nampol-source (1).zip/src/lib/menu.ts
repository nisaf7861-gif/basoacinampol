export type MenuItem = {
  name: string;
  price: string;
  note: string;
  level: number | null;
  tag?: string;
};

export const MENU: MenuItem[] = [
  {
    name: "Original Garing",
    price: "Rp 12.000",
    note: "Gurih + sedikit manis, nggak pedas. Buat yang nggak kuat cabai.",
    level: 0,
  },
  {
    name: "Pedas Level 1",
    price: "Rp 13.000",
    note: "Taburan cabai tipis. Nendang pelan, bikin lanjut terus.",
    level: 1,
  },
  {
    name: "Pedas Level 3",
    price: "Rp 15.000",
    note: "Level favorit banyak orang. Pedasnya terasa, masih aman.",
    level: 3,
    tag: "Favorit",
  },
  {
    name: "Pedas Level 5",
    price: "Rp 18.000",
    note: "Cabai rawit super. Siapin air, jangan salah estimasi.",
    level: 5,
  },
  {
    name: "Paket Hemat",
    price: "Rp 30.000",
    note: "3 bungkus campur level pilihan. Buat nonton bareng.",
    level: null,
    tag: "Hemat",
  },
  {
    name: "Borongan 1 Kg",
    price: "Rp 50.000",
    note: "Isi ±10 bungkus, harga grosir. Buat stok atau dijual lagi.",
    level: null,
  },
];

