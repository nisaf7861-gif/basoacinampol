# Roadmap

## Selesai
- Web Baso Aci Nampol (hero, level pedas, menu & harga, CTA WA, Rekomendasi AI)
- Tombol & link WA 085725417459, Shopee, TikTok @bocinampol_
- Metadata sosial/pencarian bersih dari merek Lovable
- Alamat usaha tampil di web + tombol Buka di Google Maps

## Selesai (lanjutan)
- Poster gambar boci (potret, buat status WA/TikTok)
- Poster versi kuah (potret 1080x1920, buat status WA/TikTok)

## Menunggu user
- Nama menu & harga asli (yang di web masih contoh)
- Publish web (sebutkan nama alamat yang diinginkan)
- Konfirmasi penulisan alamat: "Jakarta Barat" ditambahkan sendiri oleh Lovable
